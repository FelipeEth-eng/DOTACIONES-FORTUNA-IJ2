const botonesAbrir = document.querySelectorAll('.abrir-modal');
const botonesCerrar = document.querySelectorAll('.boton-cerrar');

// Control de apertura
botonesAbrir.forEach(boton => {
  boton.addEventListener('click', () => {
    const idModal = boton.getAttribute('data-target');
    const modal = document.getElementById(idModal); 
    
    if (modal) {
      modal.classList.add('mostrar-modal');
    }
  });
});

// Control de cierre con la X
botonesCerrar.forEach(boton => {
  boton.addEventListener('click', () => {
    const modal = boton.closest('.modal-oculto');
    if (modal) {
      modal.classList.remove('mostrar-modal');
    }
  });
});

// Control de cierre haciendo clic fuera del modal
window.addEventListener('click', (evento) => {
  if (evento.target.classList.contains('modal-oculto')) {
    evento.target.classList.remove('mostrar-modal');
  }
});